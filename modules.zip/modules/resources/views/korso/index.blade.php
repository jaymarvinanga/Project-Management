@extends('layout')

@extends('content')
<h1>tsfsdf</h1>
@stop