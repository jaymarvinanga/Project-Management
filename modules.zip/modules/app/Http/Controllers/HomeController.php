<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;

class HomeController extends Controller
{
     public function module()
    {
        return view('module');
    }
    public function html()
    {
        return view('html');
    }
     public function php()
    {
        return view('php');
    }
     public function xml()
    {
        return view('xml');
    }
     public function cssm()
    {
        return view('cssm');
    }
        public function create()
    {
        return view('create');
    }
}